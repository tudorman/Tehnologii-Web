# Gone-with-the-Script
Aplicatie web pentru partajarea experientelor utilizarii mijloacelor de transport

Obiective finale:
  Crearea contului (inscriere, editare si resetare).
  Introducerea "experientelor", vizualizarea si editarea experientelor utilizatorului.
  Cautarea altor experiente publicate, prin cuvinte cheie.
 
 Note: Pachetele externe precum npm, node.js, prime-react si altele folosite in cadrul aplicatiei trebuiesc adaugate inainte de rulare.
