function addTokens(input, tokens)
{
    const tokenName = Object.keys(tokens);
    const values = Object.values(tokens);
    const elements = Object.entries(tokens);
    try
    {
        if(typeof input != "string")
        {
            throw console.error("Input should be a string!");;
        }
        else if(input.length<6)
        {
            throw console.error("Input should have at least 6 characters!");;
        }
        else if(values)
        {
            for(let i=0;i<values.length;i++)
            {
                if(typeof values[i] !== "string")
                {
                    throw console.error("Invalid array format!");
                }
            }
        }
        else if(!input.includes('...'))
        {
            return input;
        }
        for(var value of values)
        {
            input = input.replace('...',value);
        }
        return input;
    }
    catch(ex)
    {
        console.log(ex);
    }
}

let inputString = 'Subsemnatul ... domiciliat in ....';
let tokensArray = 
{
    'subsemnat': "Manole Tudor",
    'domiciliu': 'Galati'
};
console.log(addTokens(inputString,tokensArray));